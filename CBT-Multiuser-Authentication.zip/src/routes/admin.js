const bcrypt = require('bcryptjs');
const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/summary', authenticate, authorize('admin', 'teacher'), async (req, res, next) => {
  try {
    const [[userCount]] = await pool.query('SELECT COUNT(*) AS total_users FROM users');
    const [[examCount]] = await pool.query('SELECT COUNT(*) AS total_exams FROM exams');
    const [[attemptCount]] = await pool.query('SELECT COUNT(*) AS total_attempts FROM exam_attempts');

    res.json({
      total_users: userCount.total_users,
      total_exams: examCount.total_exams,
      total_attempts: attemptCount.total_attempts
    });
  } catch (error) {
    next(error);
  }
});

router.get('/users', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT users.id, users.name, users.email, users.class_name, users.is_active, roles.name AS role
       FROM users
       JOIN roles ON roles.id = users.role_id
       ORDER BY users.id ASC`
    );

    res.json({ users: rows });
  } catch (error) {
    next(error);
  }
});

router.get('/exams', authenticate, authorize('admin', 'teacher'), async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT exams.id, exams.title, exams.duration_minutes, exams.is_active,
              subjects.name AS subject_name, users.name AS teacher_name
       FROM exams
       JOIN subjects ON subjects.id = exams.subject_id
       JOIN users ON users.id = exams.teacher_id
       ORDER BY exams.id DESC`
    );

    res.json({ exams: rows });
  } catch (error) {
    next(error);
  }
});


router.post('/users', authenticate, authorize('admin'), async (req,res,next)=>{
  try{
    const {name,email,password,role='student',class_name=''}=req.body;
    if(!name||!email||!password){return res.status(400).json({message:'Data wajib diisi'});}
    const [[r]]=await pool.query('SELECT id FROM roles WHERE name=?',[role]);
    if(!r) return res.status(400).json({message:'Role tidak valid'});
    const hash=await bcrypt.hash(password,10);
    await pool.query('INSERT INTO users(name,email,password,role_id,class_name,is_active) VALUES(?,?,?,?,?,1)',[name,email,hash,r.id,class_name]);
    res.json({message:'User berhasil ditambahkan'});
  }catch(error){next(error);}
});

module.exports = router;
